package quanlyduan.cauhinh;

public enum LoaiNhanVien {
    NHAN_VIEN_BINH_THUONG,
    NHAN_VIEN_QUAN_LY,
    LAP_TRINH_VIEN,
    THIET_KE_VIEN,
    KIEM_THU_VIEN
}
